
--
-- La base de données ex_inject_sql doit être créée avant...
--

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `login_user` varchar(8) NOT NULL,
  `pass_user` varchar(32) DEFAULT NULL,
  `nom_user` varchar(30) DEFAULT NULL,
  `prenom_user` varchar(30) DEFAULT NULL,
  `tel_user` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Table structure for table `infos`
--

DROP TABLE IF EXISTS `infos`;
CREATE TABLE `infos` (
  `id_info` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `texte_info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_info`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `infos_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
INSERT INTO `users` VALUES (1,'einstein','alb','Einstein','Albert',NULL),(2,'admin','mdp',NULL,NULL,NULL);
UNLOCK TABLES;

--
-- Dumping data for table `infos`
--

LOCK TABLES `infos` WRITE;
INSERT INTO `infos` VALUES (1,1,'Une premiere info'),(3,2,'Une autre information'),(4,2,'Une nouvelle info'),(5,2,'Passionnantes toutes ces infos !');
UNLOCK TABLES;
