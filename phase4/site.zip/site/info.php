<?php 
//ouverture de la session
session_name('EXINJECTSQL');
session_start();
//on regarde si l'utilisateur est authentifié
if (isset($_SESSION['login'])) {
	$login=$_SESSION['login'];
} else {
	echo 'Vous devez vous authentifier !';
	exit;
}

//on récupère l'id depuis l'URL
$id = $_GET['n'];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Strict//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Exemple de faille par injection SQL</title>
</head>
<body>
<h1>Une bien belle application</h1>

<h2>Détail de l'info</h2>

<?php 
//interrogation bd
include('config/db.cfg');
$c = new PDO($sgbd.':host='.$host.';dbname='.$base, $user, $passwd);
$req="select texte_info,login_user from infos natural join users where id_info = $id";
$res=$c->query($req);
$info=$res->fetch(PDO::FETCH_OBJ);

echo '<p><b>Auteur de l\'information : ' . $info->login_user . '</b></p>';
echo '<p>L\'info :</p>';
echo '<p>' . $info->texte_info . '</p>';

unset($c);

?>

<p><a href="index.php">Retour &agrave; la page d'accueil</a></p>

</body>
</html>

