/* Fonctions JS */

//-> Fonction chargée de récupérer une variable dans l'URL 
function getQuerystring(key, default_) {
       if (default_==null) default_="";
       key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
       var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
       var qs = regex.exec(window.location.href);
       if(qs == null) return default_; else return qs[1];
}

function verif() {
	var e = getQuerystring('e');
    
    switch (e) {
       case "1" : alert("Erreur d'identification !");
                break;
	}
}
