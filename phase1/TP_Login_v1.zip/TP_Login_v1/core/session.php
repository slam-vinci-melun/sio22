<?php
  // Retour type texte sans header
  echo "TODO";
?>
