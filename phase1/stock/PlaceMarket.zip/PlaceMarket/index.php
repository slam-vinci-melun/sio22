<?php
// Demarrage de la session
session_name("placemarket");
session_start();

// Numéro de page vide par défaut
$page = 0;

// Positionnement de la page
if (isset($_GET['page'])) {
    $_SESSION['page'] = $_GET['page'];
    $page = $_GET['page'];
}
?>

<!DOCTYPE HTML>
<html lang="fr">
<head>
    <title>PlaceMarket</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
    <link rel="stylesheet" href="./assets/css/main.css"/>
    <noscript>
        <link rel="stylesheet" href="./assets/css/noscript.css"/>
    </noscript>
</head>

<body class="is-preload">

<div id="wrapper">

    <header id="header">
        <div class="inner">

            <a href="index.php" class="logo">
                <span class="symbol"><img src="./images/logo.png"/></span>
                <span class="title">Place Market</span>
            </a>

            <nav>
                <ul>
                    <li><a href="#menu">Menu</a></li>
                </ul>
            </nav>

        </div>
    </header>

    <nav id="menu">
        <h2>Menu</h2>
        <ul>
            <li><a href="./index.php?page=0">Accueil</a></li>
            <li><a href="./index.php?page=1">Professionnels</a></li>
        </ul>
    </nav>

    <?php
    switch ($page) {
        case 0 :
            require_once "./core/home.php";
            break;
        case 1 :
            require_once "./core/pros.php";
            break;
    }
    ?>

    <section id="footer">
        <div class="inner">
            <ul class="copyright">
                <li>&copy; Untitled Inc. All rights reserved.</li>
                <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </div>
    </section>

</div>

<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/browser.min.js"></script>
<script src="./assets/js/breakpoints.min.js"></script>
<script src="./assets/js/util.js"></script>
<script src="./assets/js/main.js"></script>

</body>
</html>
