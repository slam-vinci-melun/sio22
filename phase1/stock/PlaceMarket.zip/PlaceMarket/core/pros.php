<?php
// Importation de la configuration
require_once "./config.php";

$mysqli = new mysqli($config['hst'], $config['usr'], $config['pss'], $config['dbn']);
$tabPros = array();
$row_cnt = 0;

// Lecture des professionnels de la base
if (!$mysqli->connect_errno) {
    $rqut = "SELECT * FROM `pro`;";

    if ($rslt = $mysqli->query($rqut)) {
        // Détermine le nombre de lignes du jeu de résultats
        $row_cnt = $rslt->num_rows;

        while ($row = $rslt->fetch_assoc()) {
            $tabPros[$row['id']] = $row;
        }

        // Libération des résultats
        $rslt->free();
    }

    // Fermeture de la connexion
    $mysqli->close();
}
?>

<div id="main">
    <div class="inner">

        <h1>Liste des professionnels ( <?php print($row_cnt); ?>)</h1>

        <section>
            <div class="col-6 col-12-medium">

                <ul class="alt">
                    <?php for ($i = 1; $i <= $row_cnt; $i++) : ?>
                        <li>
                            <img width="48" height="48"
                                 src="./images/<?php print($tabPros[$i]['prodId'] . '.png'); ?>"/>
                            &nbsp;&nbsp;&nbsp;<?php print($tabPros[$i]['identite']); ?>
                            <span style="color:#1ABC9C;">&nbsp;<?php print($tabPros[$i]['email']); ?></span>
                        </li>
                    <?php endfor; ?>
                </ul>

            </div>
        </section>
    </div>
</div>
