<div id="main">
    <div class="inner">

        <header>
            <h1>Site Web de réservation de places pour le marché</h1>
        </header>

        <section class="tiles">
            <article class="style1">
				<span class="image">
		  		<img src="./images/marche1.jpg" alt=""/>
				</span>
            </article>
            <article class="style2">
				<span class="image">
		  		<img src="./images/marche2.jpg" alt=""/>
				</span>
            </article>
            <article class="style3">
				<span class="image">
		  		<img src="./images/marche3.jpg" alt=""/>
				</span>
            </article>
        </section>

    </div>
</div>  