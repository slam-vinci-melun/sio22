<?php
// BDD
$config['hst'] = 'localhost';
$config['dbn'] = 'placemarket';
$config['usr'] = 'sio';
$config['pss'] = 'sio';
?>
