-- Base placemarket à créer !!!

CREATE TABLE `prd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activite` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

INSERT INTO `prd` (`activite`) VALUES
('Fruits et legumes'),
('Boucherie'),
('Chaussures'),
('Vetements'),
('Gadgets'),
('Poissonnerie');

CREATE TABLE `pro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `identite` varchar(255) NOT NULL,
  `prodId` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`prodId`) REFERENCES prd (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;

INSERT INTO `pro` (`email`,`identite`,`prodId`,`code`) VALUES
('adhemar.patamob@mars.fr','Adhemar Patamob','6','APM'),
('agathe.zeublouze@lune.fr','Agathe Zeublouze','3','AZL'),
('tex.ajerre@terre.fr','Tex Ajerre','1','TAT'),
('yvan.samob@mars.fr','Yvan Samob','2','YSM'),
('melusine.enfaillite@terre.fr','Melusine Enfaillite','4','MET'),
('odile.eurktumeme@venus.fr','Odile Eurktumeme','1','OEV');
