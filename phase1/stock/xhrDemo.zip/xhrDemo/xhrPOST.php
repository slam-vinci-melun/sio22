<?php
 $iv1 = $_POST['tab0'];
 $iv2 = $_POST['tab1'];
 $iv3 = $_POST['tab2'];
 
 $info = $iv1." ".$iv2." ".$iv3;
 echo $info;
?>