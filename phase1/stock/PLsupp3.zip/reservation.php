<?php
// Importation de la configuration
require_once "./config.php";

$mysqli = new mysqli($config['hst'], $config['usr'], $config['pss'], $config['dbn']);
$tabPlaces = array();

// Lecture des places de la base
if (!$mysqli->connect_errno) {
  $rqut = "SELECT * FROM `plc`;";

  if ($rslt = $mysqli->query($rqut)) {
    while ($row = $rslt->fetch_assoc()) {
      $tabPlaces[$row['id']] = $row;
    }
  }

  $totalTabPlaces = sizeof($tabPlaces);
}
?>

<div id="main">
  <div class="inner">

    <h1>Tableau de réservation des places</h1>

    <section>
      <div class="table-wrapper">
        <form method="post" action="./core/occuper.php">

          <table class="alt">

            <tbody>
              <td style="font-weight:bold;">Allée A</td>

              <?php
              for ($i = 1; $i <= 9; $i++) {
                $identifiant = "A" . $i;
                $ok = false;

                foreach($tabPlaces as $cle=>$valeur){
                  if (array_search($identifiant, $valeur)) {
                    $ok = true;
                  }
                }

                if ($ok) {
                  print("<td><input type='button' name='submit' value='" . $identifiant . "' class='primary fit small' /></td>\n");
                } else {
                  print("<td><input type='submit' name='submit' value='" . $identifiant . "' class='button fit small' /></td>\n");
                }
              }
              ?>
            </tbody>
            <tbody>
              <td style="font-weight:bold;">Allée B</td>

              <?php
              for ($i = 10; $i <= 18; $i++) {
                $identifiant = "B" . $i;
                $ok = false;

                foreach($tabPlaces as $cle=>$valeur){
                  if (array_search($identifiant, $valeur)) {
                    $ok = true;
                  }
                }

                if ($ok) {
                  print("<td><input type='button' name='submit' value='" . $identifiant . "' class='primary fit small' /></td>\n");
                } else {
                  print("<td><input type='submit' name='submit' value='" . $identifiant . "' class='button fit small' /></td>\n");
                }
              }
              ?>
            </tbody>
            <tbody>
              <td style="font-weight:bold;">Allée C</td>

              <?php
              for ($i = 19; $i <= 27; $i++) {
                $identifiant = "C" . $i;
                $ok = false;

                foreach($tabPlaces as $cle=>$valeur){
                  if (array_search($identifiant, $valeur)) {
                    $ok = true;
                  }
                }

                if ($ok) {
                  print("<td><input type='button' name='submit' value='" . $identifiant . "' class='primary fit small' /></td>\n");
                } else {
                  print("<td><input type='submit' name='submit' value='" . $identifiant . "' class='button fit small' /></td>\n");
                }
              }
              ?>
            </tbody>

          </table>

          <!-- TO DO Qustion 3.2 -->
          
        </form>


      </div>
    </section>

  </div>
</div>
