<?php
// Demarrage de la session
session_name("placemarket");
session_start();

// Récupération de la configuration
require_once "../config.php";
// Positionnement du flag de la réservation
$nbrReservation = 0;
// Connexion à la BDD
$mysqli = new mysqli($config['hst'], $config['usr'], $config['pss'], $config['dbn']);

// Requête pour la récupération du nombre de réservations du professionnel
$rqut = "SELECT reservation FROM `pro` WHERE `id` = " . $_POST['idPro'] . ";";

if ($rslt = $mysqli->query($rqut)) {
  $row_count = $rslt->num_rows;

  if ($row_count > 0) {
    $row = $rslt->fetch_row();
    $nbrReservation = $row[0];
  }

  // TO DO Qustion 3.4

}

$mysqli->close();

header('Location: ../index.php?page=2');
