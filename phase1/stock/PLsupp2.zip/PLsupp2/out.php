<?php
 // Ouverture de la session
 session_name( "placemarket" );
 session_start();

 // Detruit toutes les variables de session
 $_SESSION = array();

 // Detruit le cookie et les données de session !
 if (ini_get("session.use_cookies")) {
  $params = session_get_cookie_params();
  setcookie(session_name(), '', time()-42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"] );
 }

 // Destruction definitive de la session
 session_destroy();

 // Redirection vers la page d'identification pour sortie
 header ( "Location: ./index.php" );
 ?>