<div id="main">
  <div class="inner">

    <h1>Authentification</h1>

    <section>

      <form method="post" action="./core/verif.php">
        <div class='row gtr-uniform'>
          <div class="col-6 col-12-xsmall">
            <input type='text' name='login' id='login' placeholder="Login" />
          </div>
        </div>
        <div class='row gtr-uniform'>
          <div class="col-6 col-12-xsmall">
            <input class='validate' type='password' name='password' id='password' placeholder="Mot de passe" />
          </div>
          <div class="col-12">
            <ul class="actions">
              <li><input type="submit" value="Validation" class="primary" /></li>
            </ul>
          </div>
        </div>
      </form>

    </section>
  </div>
</div>