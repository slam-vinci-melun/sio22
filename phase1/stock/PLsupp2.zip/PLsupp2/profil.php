<?php
// Importation de la configuration
require_once "./config.php";

// Récupération de l'intitulé de l'activité
$mysqli = new mysqli($config['hst'], $config['usr'], $config['pss'], $config['dbn']);
$activite = "inconnue";

if (!$mysqli->connect_errno) {
  $rqut = "SELECT * FROM `prd` WHERE id = " . $_SESSION['prodId'] . ";";
  $row_count = 0;

  if ($rslt = $mysqli->query($rqut)) {
    while ($row = $rslt->fetch_assoc()) {
      $activite = $row['activite'];
    }
  }
}
?>

<div id="main">
  <div class="inner">

    <h1>Profil de l'utilisateur</h1>

    <section>
      <div class="col-6 col-12-medium">
        <ul class="alt">
          <li><?php print("<img src='./images/c" . $_SESSION['prodId'] . ".jpg' />"); ?></li>
          <li><?php print($_SESSION['identite']); ?></li>
          <li><?php print($_SESSION['email']); ?></li>
          <li><?php print($activite . " | Code : " . $_SESSION['code']); ?></li>
        </ul>
      </div>
    </section>
  </div>
</div>