<?php
 // Demarrage de la session
 session_name("placemarket");
 session_start();

 // Récupération de la configuration
 require_once "../config.php";
 // Positionnement du flag de sortie
 $sortie = false;
 // Connexion à la BDD
 $mysqli = new mysqli($config['hst'],$config['usr'],$config['pss'],$config['dbn']);

 // Récupération des champs
 $log = $_POST['login'];
 $mdp = $_POST['password'];
 
 // Vérification des éléments de connexion
 if (!$mysqli->connect_errno) {
  $rqut = "SELECT * FROM `pro` WHERE login ='$log' AND password='$mdp'";
  $row_count = 0;

  if ($rslt = $mysqli->query($rqut)) {
   $row_count = $rslt->num_rows;
   
   if ($row_count>0) {
    $rslt->data_seek(0);
    $row = $rslt->fetch_array();

    // Transmission de l'identifiant de l'utilisateur et celui de la page par défaut
    $_SESSION['id'] = $row['id'];
    $_SESSION['email'] = $row['email'];
    $_SESSION['login'] = $log;
    $_SESSION['identite'] = $row['identite'];
    $_SESSION['prodId'] = $row['prodId'];
    $_SESSION['code'] = $row['code'];

    $rslt->close();
    // Ok pour la connexion
    $sortie = true;
   }
  }

  $mysqli->close();
 }

 if ($sortie) {
  header('Location: ../index.php?page=0');
 } else {
    header('Location: ../index.php?page=8');
   }
 ?>
