
function envoiJSon() {
	let lejson = document.getElementById("lejson").value;

	$.post(
    'pokemon.php',
		lejson,
    retourEnvoi,
    'text'
  );

/*
	let lejson = document.getElementById("lejson").value;
	alert(lejson);
*/


}

function retourEnvoi(message) {
	alert(message);
}
