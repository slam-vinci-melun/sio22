/* main.js */

// Initialisation aléatoire de l'affichage du tableau des chiffres
function remplissageTableau() {
    let leTab = [];
    let cpt = 10;

    while (cpt > 0) {
        let nbr = Math.floor(Math.random() * 10);

        if (leTab.indexOf(nbr) === -1) {
            leTab.push(nbr);
            cpt--;
        }
    }

    console.log(leTab);
    return leTab;
}

// Initialisation du tableau des chiffres sélectionnés
var tabChiffresSelect = [];

// Mise en place de du choix de code de l'utilisateur
function remplissageSelect(chiffre) {
    tabChiffresSelect.push(chiffre);
}

// Lancement au chargement de la page
window.onload = function () {
    // Initialisations diverses
    let tabChiffres = remplissageTableau();
    let ligneChiffres = document.getElementById("ligne");
    let va = document.getElementById("validation");
    let lu = document.getElementById("labelUser");
    let lc = document.getElementById("labelCode");

    // Affichage des boutons représentant les chiffres
    for (let i = 0; i < tabChiffres.length; i++) {
          ligneChiffres.insertCell(-1).innerHTML =
            `<input id='${i}'
            type='button' class='chiffre'
            onclick='remplissageSelect(${tabChiffres[i]})'
            value='${tabChiffres[i]}' />`
    }

    // Traitement au clic du bouton validation
    va.addEventListener('click', () => {
        let sortie = true;
        let valeurUser = document.getElementById("user").value;
        console.log(valeurUser);
        console.log((tabChiffresSelect));

        // Test de l'existence du login
        if (!valeurUser) {
            lu.style = "color:orange;";
            lu.innerHTML = "Login -> champ vide !";
            sortie = false;
        }

        // Test du nombre de chiffres sélectionnés
        if (tabChiffresSelect.length !== 6) {
            lc.style = "color:orange;";
            lc.innerHTML = "Code -> longueur différente de 6 !";
            tabChiffresSelect = [];
            sortie = false;
        }

        // Envoi par AJAX des sasies
        if (sortie) {
          // Sauf que pour l'instant... ce n'est pas fait !
          document.location.href = "https://www.vinsio.fr";
        }
    });
}
