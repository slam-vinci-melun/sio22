
function envoiJSon() {
	let lejson = document.getElementById("lejson").value;	
	$.post('pokemon.php',lejson,retourEnvoi,'text');
}

function retourEnvoi(message) {
	alert(message);
}
