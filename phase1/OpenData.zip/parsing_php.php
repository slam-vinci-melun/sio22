<!DOCTYPE HTML>
<html lang="fr">
	<head>
		<title>Parsing JSon/PHP</title>
		<meta charset="utf-8" />
	</head>

	<body>

	<?php
		$json = file_get_contents("idf_sncf.json");
		// Sortie du premier élément sous forme d'objet, paramètre false 
		$parsed_json = json_decode($json,false);
		print("<p>\n");
		print_r($parsed_json[0]);
		print("</p>\n");
 
		// Sortie du premier élément sous forme de tableau associatif, paramètre true 
		// Les traitements suivants seront sous cette forme
		$parsed_json = json_decode($json,true);

		print("<p>\n");
		print_r($parsed_json[0]);
		print("</p>\n");

		// On enlève un objet
 		foreach ($parsed_json as &$value) {
    		unset($value['datasetid']);
 		}
 
		// Affichage seuleument des trois premiers
		print("<p>\n");
		print_r($parsed_json[0]);
		print_r($parsed_json[1]);
		print_r($parsed_json[2]);
		print("</p>\n");
 
		// On enlève un élément
		foreach ($parsed_json as $i => &$value) {
    		foreach ($parsed_json[$i] as $key => $valfields) {
       			if ($key=="fields") {
					if (isset($valfields['desserte'])) {
						$code = $valfields['desserte'];

        				if ($code=="C") {
							// unset($parsed_json[$i]);
							array_splice($parsed_json,$i,1);  
						}
					}	
       			}
    		}
		}
		  
		// Affichage seuleument des trois premiers
		print("<p>\n");
		print_r($parsed_json[0]);
		print_r($parsed_json[1]);
		print_r($parsed_json[2]);
		print("</p>\n");

	 	// Pour voir la structure (très long)
 		// var_dump(json_decode($json));
	 ?>
	
	</body>
</html>
