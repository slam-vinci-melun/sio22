<?php
 $info = $_GET['info'];
 echo $info;
?>