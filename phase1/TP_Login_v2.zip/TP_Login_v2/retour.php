<?php
  // Récupération des variables du formulaire
  $login = $_POST['login'];
  $passw = $_POST['passw'];
?>

<!DOCTYPE html>
<html lang="fr">
 <head>

  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="UTF-8">

  <title>EduDock - Le spatiodock de l'éducation</title>
  <!-- Indique au navigateur d'être "responsive" avec la taille de l'écran -->
  <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>

  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/fonts.css">

 </head>

  <body>

   <div class="wrapper">
    <div class="container">
     <h1>Acc&egrave;s au Dock pour :</h1>

     <h1>Login : </p><?php print($login) ?>
     <h1>Passe : </p><?php print($passw) ?>

    </div>
   </div>

  </body>
</html>
