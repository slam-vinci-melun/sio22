<?php
 // Récupération des informations de connexion à la BDD
 require_once "./connexion.php";

 // Récupération des variables du formulaire
 $login = $_POST['login'];
 $passw = $_POST['passw'];

 // Requête pour le mot de passe
 $query = "SELECT * FROM `user` WHERE login LIKE '".$login."' AND passw LIKE '".$passw."';";
 $result = $mysqli->query ( $query );

 // Autre solution :
 // if (($row[1]==$login) && ($row[2]==$passw)) {

 // Indique null si pas trouvé
 if ( $row = $result->fetch_row()) {
  $result->close();
  // Redirection correcte
  $page = "Location: ../index.html?user=".$login;
 } else {
    // Redirection pour l'erreur
    $page = "Location: ../index.html?user=bad";
 }

 $mysqli->close ();

 // Redirection vers la page adéquate
 header ( $page );

 exit ();
?>

