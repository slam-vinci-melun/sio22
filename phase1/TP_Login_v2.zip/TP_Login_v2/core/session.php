<?php
    // Récupération des variables du formulaire
    $login = $_POST['login'];
    $passw = $_POST['passw'];

    // Redirection vers la page adéquate
    header( "Location: ../retour.php" );

    // Pour être sûr de sortir du script
    exit ();
?>
