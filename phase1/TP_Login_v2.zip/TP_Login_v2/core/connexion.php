<?php
    //-> Variables de connexion
    $DB_NAME = 'edudock';
    $DB_HOST = 'localhost';
    $DB_USER = 'sio';
    $DB_PASS = 'sio';
  
    //-> Connexion a la base
    $mysqli = new mysqli($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
    
    //-> Encodage en utf8
    $mysqli->set_charset("utf8");

    //-> Traitement de l'erreur de connexion
    if (mysqli_connect_errno()) {
     printf("Erreur : %s\n",mysqli_connect_error());
     exit("Erreur de connexion");
    }
?>