/* Fonctions JS */

//-> Fonction chargée de récupérer une variable dans l'URL 
function getQuerystring(key, default_) {
       if (default_ == null) default_ = "";
       key = key.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
       let regex = new RegExp("[\\?&]" + key + "=([^&#]*)");
       let qs = regex.exec(window.location.href);
       if (qs == null) return default_; else return qs[1];
}

function verif() {
       // Y a t'il un paramètre ? 
       if (getQuerystring('user')) {
              let identifiant = getQuerystring('user');

              if (identifiant == "bad") {
                     document.getElementById("message").innerHTML="Mauvaise identification !!!";
              } else {
                     document.getElementById("message").innerHTML=identifiant;
                     // Stockage dans le localstorage
                     localStorage.setItem('user',identifiant);
              }
       } else {
              // Y a t'il un utilisateur de stocké ? 
              if(localStorage.getItem('user')) {
                     document.getElementById("message").innerHTML=localStorage.getItem('user');
              };
       }
}
